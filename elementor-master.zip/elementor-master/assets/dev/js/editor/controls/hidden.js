import ControlBaseDataView from './base-data';

module.exports = ControlBaseDataView.extend( {}, { onPasteStyle: () => false } );
