export { default as DynamicComponent } from '../document/dynamic/component';
export { default as ElementsComponent } from '../document/elements/component';
export { default as GlobalsComponent } from '../document/globals/component';
export { default as HistoryComponent } from '../document/history/component';
export { default as RepeaterComponent } from '../document/repeater/component';
export { default as SaveComponent } from '../document/save/component';
export { default as UIComponent } from '../document/ui/component';
