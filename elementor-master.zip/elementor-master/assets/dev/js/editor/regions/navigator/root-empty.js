export default class extends Marionette.ItemView {
	getTemplate() {
		return '#tmpl-elementor-navigator__root--empty';
	}

	className() {
		return 'elementor-nerd-box';
	}
}
