import BackgroundSlideshow from './background-slideshow';

export default [ BackgroundSlideshow ];

