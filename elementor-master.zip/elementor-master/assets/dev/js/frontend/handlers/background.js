import BackgroundSlideshow from './background-slideshow';
import BackgroundVideo from './background-video';

export default [
	BackgroundSlideshow,
	BackgroundVideo,
];
