export default [
	() => import( /* webpackChunkName: 'container' */ './handles-position' ),
	() => import( /* webpackChunkName: 'container' */ './shapes' ),
];
