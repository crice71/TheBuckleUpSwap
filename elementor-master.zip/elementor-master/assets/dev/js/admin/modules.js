import MenuHandler from 'elementor-admin/menu-handler';

elementorModules.admin = {
	MenuHandler,
};
