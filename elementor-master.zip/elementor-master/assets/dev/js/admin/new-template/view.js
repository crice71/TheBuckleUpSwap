module.exports = Marionette.ItemView.extend( {

	id: 'elementor-new-template-dialog-content',

	template: '#tmpl-elementor-new-template',

	ui: {},

	events: {},

	onRender: function() {},
} );
