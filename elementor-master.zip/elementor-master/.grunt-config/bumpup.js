/**
 * Grunt bumpup task config
 * @package Elementor
 */
module.exports = {
	options: {
		updateProps: {
			pkg: 'package.json'
		}
	},
	file: 'package.json'
};
